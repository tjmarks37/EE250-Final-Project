To update the firmware to the latest version (Currently version 1.4)
```
cd /home/pi/Dexter/GrovePi/Firmware
sudo bash firmware_update.sh
```
