#TWEET YOUR VALUES

This folder contains the code necessary to tweet your sensor values once a minute.

It requires python-twitter library which you can get by

**sudo pip install python-twitter**

Sensors used in this code are:
* light sensor on port A1
* sound sensor on port A0
* temperature and humidity sensor on port D2
* LED for visual feedback on port D3 (with PWM)
