## **GrovePi Weather Station**

- **Raspberry Pi Classroom Weather Station**: Read the local weather and record it to a file.
- **Sensor Connections on the GrovePi:**
     * [Grove light sensor](http://www.dexterindustries.com/shop/grove-light-sensor/) - Port A2 
     * [Grove Temperature and Humidity Sensor](http://www.dexterindustries.com/shop/grovepi-starter-kit-raspberry-pi/) - Port D4 
     * [Raspberry Pi Camera](http://www.dexterindustries.com/shop/raspberry-pi-camera/)
     * Grove Pressure sensor (BMP 180) - Any I2C port, I2C-1, I2C-2, or I2C-3.

See more at the [GrovePi Site](http://dexterindustries.com/GrovePi/).

## License
.
The MIT License (MIT)

GrovePi for the Raspberry Pi: an open source platform for connecting Grove Sensors to the Raspberry Pi.
Copyright (C) 2017  Dexter Industries

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in
all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
THE SOFTWARE.
