﻿namespace GrovePi
{
    public enum Pin
    {
        AnalogPin0 = 0,
        AnalogPin1 = 1,
        AnalogPin2 = 2,
        DigitalPin2 = 2,
        DigitalPin3 = 3,
        DigitalPin4 = 4,
        DigitalPin5 = 5,
        DigitalPin6 = 6,
        DigitalPin7 = 7,
        DigitalPin8 = 8
    }
}