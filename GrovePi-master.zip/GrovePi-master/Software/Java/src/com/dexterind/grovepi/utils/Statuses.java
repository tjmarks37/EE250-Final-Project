package com.dexterind.grovepi.utils;

public class Statuses {
  public static final int OK = 1;
  public static final int ERROR = -1;
  public static final int INIT = 2;

  public Statuses(){}
}