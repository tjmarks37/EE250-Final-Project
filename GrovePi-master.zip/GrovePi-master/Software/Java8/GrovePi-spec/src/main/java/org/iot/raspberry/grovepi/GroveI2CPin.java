package org.iot.raspberry.grovepi;

public @interface GroveI2CPin {

}
