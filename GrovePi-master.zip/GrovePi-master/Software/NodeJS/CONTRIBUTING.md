## How to contribute to GrovePi for Node.js

* Before you open a ticket or send a pull request, [search](https://github.com/DexterInd/GrovePi/issues) for previous discussions about the same feature or issue. Add to the earlier ticket if you find one.

* Use the coding style suggested by [npmjs](https://docs.npmjs.com/misc/coding-style).

* Be creative :-)