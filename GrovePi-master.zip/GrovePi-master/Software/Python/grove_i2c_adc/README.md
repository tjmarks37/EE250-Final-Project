Grove I2C ADC
==============
Raspberry Pi Python i2c library for Grove I2C ADC (http://www.seeedstudio.com/depot/Grove-I2C-ADC-p-1580.html)

Grove - I2C ADC is a 12-bit precision ADC module based on ADC121C021. It helps you increase the accuracy of value collected from analog sensor by providing a constant reference voltage. Because its address is changeable, you can use up to 9 I2C ADC at the same time at most